#STUDENTS' PERFORMANCES
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
from sklearn.metrics import mean_squared_error
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestRegressor

df = pd.read_csv('StudentsPerformance.csv')
#created average column
math = df['math score']
read = df['reading score']
write = df['writing score']
df['average'] = (df['math score'] + df['reading score'] + df['writing score'])/3
#training, testing and splitting
x = df[['lunch','test preparation course']]
y = df['average']
x_train, x_test, y_train, y_test = train_test_split(x,y, train_size=0.3, random_state=42)
#processing
categorical_features = ['lunch','test preparation course']
categorical_transformer = OneHotEncoder(drop='first')

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', categorical_transformer, categorical_features)
    ])

pipeline = Pipeline([
   ('precessor', preprocessor),
    ('model', RandomForestRegressor(random_state=42))
])

pipeline.fit(x_train, y_train)
#prediction
y_pred = pipeline.predict(x_test)
print('R2:', r2_score(y_test, y_pred))
print('MSE:', mean_squared_error(y_test, y_pred))







